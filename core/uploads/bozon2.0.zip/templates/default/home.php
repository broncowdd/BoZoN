		<div class="w1000">
		
			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/bozondd.png"/><p>1 <?php e('Drag the file you want to share to upload it on the server');?></p></div>
			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/bozonsh.png"/><p>2 <?php e('Copy the file\'s link (right click on it)');?></p></div>
			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/bozoncc.png"/><p>3 <?php e('Share the link with your buddies...');?></p></div>
			<div style="clear:both"></div>

			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/locked_big.png"/><p> <?php e('Lock the access to the file/folder with a password');?><br/><small><?php e('If you want to remove the password, just click on Renew button');?></small></p></div>
			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/burn_big.png"/><p> <?php e('When burn is on, the user can access the file/folder only once');?></p></div>
			<div class="w33"><img src="<?php echo THEME_PATH;?>/img/renew_big.png"/><p> <?php e('Renew the share link of the file/folder (in case of a stolen link for example)');?></p></div>	



		</div><div style="clear:both"></div>