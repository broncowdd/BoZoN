<?php
# ENGLISH
	$lang=array();
?>